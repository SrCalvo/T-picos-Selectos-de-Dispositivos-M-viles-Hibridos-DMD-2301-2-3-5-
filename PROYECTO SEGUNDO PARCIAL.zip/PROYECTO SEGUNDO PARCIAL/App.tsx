import React, { useState } from 'react';
import { StyleSheet, View } from 'react-native';
import IndexScreen from './components/index';
import HamburgerMenu from './components/menu';

const App = () => {
  const [showWelcome, setShowWelcome] = useState(true);

  const handleEnterApp = () => {
    setShowWelcome(false);
  };

  const handleGoToWelcome = () => {
    setShowWelcome(true);
  };

  return (
    <View style={styles.container}>
      {showWelcome ? (
        <IndexScreen onEnter={handleEnterApp} />
      ) : (
        <HamburgerMenu onGoToWelcome={handleGoToWelcome} />
      )}
    </View>
  );
};

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
});
