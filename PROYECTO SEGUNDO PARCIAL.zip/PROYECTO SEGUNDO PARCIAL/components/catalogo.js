import React, { useState } from 'react';
import {
  View,
  FlatList,
  Image,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Modal,
  ImageBackground,
} from 'react-native';

const numColumns = 2;
const screenWidth = Dimensions.get('window').width;
const cardWidth = screenWidth / numColumns - 15;

const products = [
  {
    id: '1',
    name: 'Playera Twice',
    price: '$249.00',
    image: require('../assets/products/producto1.jpg'),
  },
  {
    id: '2',
    name: 'BlinkBong',
    price: '$799.00',
    image: require('../assets/products/producto2.jpg'),
  },
  {
    id: '3',
    name: 'CandyBong',
    price: '$499.00',
    image: require('../assets/products/producto3.jpg'),
  },
  {
    id: '4',
    name: 'Album Twice Twicetagram',
    price: '$349.00',
    image: require('../assets/products/producto4.png'),
  },
  {
    id: '5',
    name: 'Album Twice Strategy',
    price: '$199.00',
    image: require('../assets/products/producto5.jpg'),
  },
];

const Catalogo = () => {
  const [selectedImage, setSelectedImage] = useState(null);

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => setSelectedImage(item.image)}
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.price}>{item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <ImageBackground
      source={require('../assets/a1.jpg')}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.header}>
        <Text style={styles.catalogTitle}>Catálogo de Productos</Text>
        <Text style={styles.catalogSubtitle}>Los mejores productos K-Pop</Text>
      </View>

      <FlatList
        data={products}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        numColumns={numColumns}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        style={styles.flatList}
      />

      {/* Modal para ver la imagen ampliada */}
      <Modal visible={!!selectedImage} transparent={true} animationType="fade">
        <TouchableOpacity
          style={styles.modal}
          activeOpacity={1}
          onPress={() => setSelectedImage(null)}
        >
          <Image source={selectedImage} style={styles.fullImage} />
          <Text style={styles.closeText}>Toca para cerrar</Text>
        </TouchableOpacity>
      </Modal>
    </ImageBackground>
  );
};

export default Catalogo;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    alignItems: 'center',
    marginBottom: 10,
  },
  catalogTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#e84393',
    textShadowColor: 'rgba(255, 255, 255, 0.8)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  catalogSubtitle: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 5,
    color: '#6c5ce7',
    fontWeight: '500',
  },
  flatList: {
    flex: 1,
  },
  listContent: {
    paddingBottom: 20,
    paddingHorizontal: 10,
  },
  card: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    width: cardWidth,
    borderRadius: 16,
    margin: 5,
    padding: 15,
    alignItems: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 6,
    borderWidth: 2,
    borderColor: '#fd79a8',
  },
  image: {
    width: '100%',
    height: 120,
    borderRadius: 12,
    backgroundColor: '#f8f8f8',
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
    marginTop: 8,
    textAlign: 'center',
    color: '#2d3436',
  },
  price: {
    fontSize: 16,
    color: '#e84393',
    marginTop: 4,
    fontWeight: 'bold',
  },
  modal: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.95)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  fullImage: {
    width: '90%',
    height: '60%',
    borderRadius: 10,
    resizeMode: 'contain',
  },
  closeText: {
    color: 'white',
    marginTop: 20,
    fontSize: 16,
    fontWeight: '500',
  },
});
