import React from 'react';
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Text,
  ScrollView,
  ImageBackground,
} from 'react-native';

export default function Botones() {
  return (
    <ImageBackground
      source={require('../assets/car.jpg')}
      style={styles.background}
      resizeMode="cover"
    >
      <ScrollView style={styles.scrollView}>
        <View style={estilos.principal}>
          {/* BLACKPINK 💗🖤 */}
          <TouchableOpacity
            style={estilos.botonBlackpink}
            onPress={() => alert('💗 ¡BLACKPINK en tu área! 🖤')}
          >
            <Text style={estilos.texto}>BLACKPINK 💗🖤</Text>
          </TouchableOpacity>

          {/* TWICE 💖💙 */}
          <TouchableOpacity
            style={estilos.botonTwice}
            onPress={() => alert('💖 ¡Me hiciste sentir especial! 💙')}
          >
            <Text style={estilos.texto}>TWICE 💖💙</Text>
          </TouchableOpacity>

          {/* AESPA 💜🩵 */}
          <TouchableOpacity
            style={estilos.botonAespa}
            onPress={() => alert('💜 ¡Bienvenido al mundo æ! 🩵')}
          >
            <Text style={estilos.texto}>AESPA 💜🩵</Text>
          </TouchableOpacity>

          {/* BTS 💜🌟 */}
          <TouchableOpacity
            style={estilos.botonBTS}
            onPress={() => alert('💜 ¡Borahae! Eres mi esperanza 🌟')}
          >
            <Text style={estilos.texto}>BTS 💜🌟</Text>
          </TouchableOpacity>

          {/* COD ZOMBIES 🧟‍♂️🔫 */}
          <TouchableOpacity
            style={estilos.botonCODZombies}
            onPress={() => alert('🧟‍♂️ ¡Round 1! ¡Preparen sus armas! 🔫')}
          >
            <Text style={estilos.textoCOD}>COD ZOMBIES 🧟‍♂️🔫</Text>
          </TouchableOpacity>

          {/* RED VELVET 💗💛 */}
          <TouchableOpacity
            style={estilos.botonRedVelvet}
            onPress={() => alert('💗 ¡Siente mi ritmo! 💛')}
          >
            <Text style={estilos.texto}>RED VELVET 💗💛</Text>
          </TouchableOpacity>

          {/* STRAY KIDS 🐺💙 */}
          <TouchableOpacity
            style={estilos.botonStrayKids}
            onPress={() =>
              alert('🐺 ¡Stray Kids en todas partes del mundo! 💙')
            }
          >
            <Text style={estilos.texto}>STRAY KIDS 🐺💙</Text>
          </TouchableOpacity>

          {/* ITZY 💚💫 */}
          <TouchableOpacity
            style={estilos.botonItzy}
            onPress={() =>
              alert('💚 ¡Voy a ser una estrella! ¡Confía en mí! 💫')
            }
          >
            <Text style={estilos.texto}>ITZY 💚💫</Text>
          </TouchableOpacity>

          {/* NCT 🌐💚 */}
          <TouchableOpacity
            style={estilos.botonNCT}
            onPress={() => alert('🌐 ¡Para el mundo! ¡Somos NCT! 💚')}
          >
            <Text style={estilos.texto}>NCT 🌐💚</Text>
          </TouchableOpacity>

          {/* (G)I-DLE 🦋🧡 */}
          <TouchableOpacity
            style={estilos.botonGIdle}
            onPress={() => alert('🦋 ¡Yo nunca muero! ¡Sí, soy una reina! 🧡')}
          >
            <Text style={estilos.texto}>(G)I-DLE 🦋🧡</Text>
          </TouchableOpacity>

          {/* LE SSERAFIM 🌸🤍 */}
          <TouchableOpacity
            style={estilos.botonLeSserafim}
            onPress={() => alert('🌸 ¡Soy impávida! ¡Sí, no nos rendimos! 🤍')}
          >
            <Text style={estilos.texto}>LE SSERAFIM 🌸🤍</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  scrollView: {
    flex: 1,
  },
});

const estilos = StyleSheet.create({
  principal: {
    marginHorizontal: 30,
    alignItems: 'center',
    paddingVertical: 100,
  },

  texto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
    textAlign: 'center',
    textShadowColor: '#000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },

  textoCOD: {
    color: '#00ff00',
    fontWeight: 'bold',
    fontSize: 18,
    textAlign: 'center',
    textShadowColor: '#00ff00',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },

  // Estilo BLACKPINK 💗🖤 - Diseño degradado rosa
  botonBlackpink: {
    backgroundColor: '#ff69b4',
    padding: 20,
    borderRadius: 40,
    marginBottom: 15,
    width: '100%',
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
    borderLeftWidth: 8,
    borderLeftColor: '#ff1493',
    borderRightWidth: 8,
    borderRightColor: '#c71585',
  },

  // Estilo TWICE 💖💙 - Diseño con patrón de corazones
  botonTwice: {
    backgroundColor: '#ffb6c1',
    padding: 20,
    borderRadius: 40,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#00bfff',
    borderStyle: 'dashed',
    shadowColor: '#00bfff',
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 5,
    transform: [{ rotate: '-2deg' }],
  },

  // Estilo AESPA 💜🩵 - Diseño futurístico
  botonAespa: {
    backgroundColor: '#9370db',
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
    borderWidth: 3,
    borderColor: '#00ced1',
    shadowColor: '#00ced1',
    shadowOpacity: 0.6,
    shadowRadius: 10,
    elevation: 8,
    borderTopWidth: 0,
    borderBottomWidth: 6,
  },

  // Estilo BTS 💜🌟 - Diseño estelar
  botonBTS: {
    backgroundColor: '#8a2be2',
    padding: 20,
    borderRadius: 50,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#ffd700',
    shadowColor: '#8a2be2',
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 10,
    borderStyle: 'dotted',
  },

  // Estilo COD ZOMBIES 🧟‍♂️🔫 - Temática zombie militar
  botonCODZombies: {
    backgroundColor: '#2f4f4f',
    padding: 20,
    borderRadius: 5,
    marginBottom: 15,
    borderWidth: 3,
    borderColor: '#556b2f',
    shadowColor: '#00ff00',
    shadowOpacity: 0.7,
    shadowRadius: 12,
    elevation: 9,
    borderLeftWidth: 10,
    borderLeftColor: '#8b0000',
    borderRightWidth: 10,
    borderRightColor: '#006400',
  },

  // Estilo RED VELVET 💗💛 - Diseño de terciopelo
  botonRedVelvet: {
    backgroundColor: '#ff4444',
    padding: 20,
    borderRadius: 35,
    marginBottom: 15,
    borderWidth: 5,
    borderColor: '#ffeb3b',
    borderTopColor: '#ff6b6b',
    borderBottomColor: '#c23636',
    shadowColor: '#ff4444',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },

  // Estilo STRAY KIDS 🐺💙 - Diseño urbano
  botonStrayKids: {
    backgroundColor: '#1e90ff',
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#000000',
    shadowColor: '#1e90ff',
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 10,
    transform: [{ skewX: '-5deg' }],
  },

  // Estilo ITZY 💚💫 - Diseño energético
  botonItzy: {
    backgroundColor: '#32cd32',
    padding: 20,
    borderRadius: 45,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#ff69b4',
    borderStyle: 'double',
    shadowColor: '#32cd32',
    shadowOpacity: 0.6,
    shadowRadius: 15,
    elevation: 9,
  },

  // Estilo NCT 🌐💚 - Diseño geométrico
  botonNCT: {
    backgroundColor: '#00ff7f',
    padding: 20,
    borderRadius: 0,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#1e90ff',
    borderTopColor: '#00ff7f',
    borderBottomColor: '#1e90ff',
    borderLeftColor: '#00ff7f',
    borderRightColor: '#1e90ff',
    shadowColor: '#00ff7f',
    shadowOpacity: 0.7,
    shadowRadius: 20,
    elevation: 12,
    transform: [{ rotate: '3deg' }],
  },

  // Estilo (G)I-DLE 🦋🧡 - Diseño orgánico
  botonGIdle: {
    backgroundColor: '#ff8c00',
    padding: 20,
    borderRadius: 60,
    marginBottom: 15,
    borderWidth: 3,
    borderColor: '#9370db',
    borderTopLeftRadius: 20,
    borderBottomRightRadius: 20,
    shadowColor: '#ff8c00',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 8,
  },

  // Estilo LE SSERAFIM 🌸🤍 - Diseño elegante
  botonLeSserafim: {
    backgroundColor: '#f20b0bff',
    padding: 20,
    borderRadius: 40,
    marginBottom: 15,
    borderWidth: 4,
    borderColor: '#ff69b4',
    borderTopColor: '#ffb6c1',
    borderBottomColor: '#ff1493',
    shadowColor: '#ff69b4',
    shadowOpacity: 0.4,
    shadowRadius: 15,
    elevation: 10,
  },
});
