import React, { useState, useEffect, useContext, createContext } from 'react';
import {
  View,
  Text,
  Button,
  StyleSheet,
  SafeAreaView,
  Image,
} from 'react-native';

const UsuarioContext = createContext(null);

const estudiantePrincipal = {
  nombreCompleto: 'JHONATAN JAZAEL ONTAÑON ORTIZ',
  rol: 'Alumno',
  matricula: '',
  foto: require('../assets/cred.png'),
};

const datosReverso = {
  rfc: '',
  curp: '',
  vigencia: 'AC 25',
  direccion:
    'Paraje San Isidro S/N, Barrio Tecamachalco, La Paz, C.P. 56400, Estado de México.',
};

function CredencialFrente() {
  const { estudiante } = useContext(UsuarioContext);
  return (
    <View style={styles.credencialContainer}>
      <Image
        source={require('../assets/colibri_fondo.jpeg')}
        style={styles.colibriFondo}
      />

      <View style={styles.header}>
        <Image
          source={require('../assets/logos_educacion.jpeg')}
          style={styles.logo}
        />
      </View>

      <View style={styles.body}>
        <Image source={estudiante.foto} style={styles.fotoPerfil} />
        <Text style={styles.nombre}>{estudiante.nombreCompleto}</Text>

        <Image
          source={require('../assets/flor_central.jpeg')}
          style={styles.florCentral}
        />

        <Text style={styles.rol}>{estudiante.rol}</Text>
        <Text style={styles.matricula}>{estudiante.matricula}</Text>
      </View>

      <View style={styles.footer}>
        <Text style={styles.educacionTexto}>EDUCACIÓN</Text>
        <Text style={styles.subtextoEducacion}>
          SECRETARÍA DE EDUCACIÓN, CIENCIA, TECNOLOGÍA E INNOVACIÓN
        </Text>
        <Text style={styles.tesoemTexto}>
          TECNOLÓGICO DE ESTUDIOS SUPERIORES DE ORIENTE DEL ESTADO DE MÉXICO
        </Text>
      </View>
    </View>
  );
}

function CredencialReverso() {
  const { rfc, curp, vigencia, direccion } = datosReverso;

  return (
    <View style={styles.credencialContainerReverso}>
      <Image
        source={require('../assets/colibri_fondo.jpeg')}
        style={styles.colibriFondoReverso}
      />
      <Image
        source={require('../assets/flor_central.jpeg')}
        style={styles.florCentralReverso}
      />

      <View style={styles.reversoContent}>
        <Text style={styles.reversoTexto}>
          <Text style={styles.reversoLabel}>RFC:</Text> {rfc}
        </Text>
        <Text style={styles.reversoTexto}>
          <Text style={styles.reversoLabel}>CURP:</Text> {curp}
        </Text>

        <View style={styles.firmaContainer}>
          <Text style={styles.firmaLabel}>___________________________</Text>
          <Text style={styles.firmaSubLabel}>Firma del Alumno</Text>
        </View>

        <View style={styles.firmaContainer}>
          <Text style={styles.firmaLabel}>___________________________</Text>
          <Text style={styles.firmaSubLabel}>Jefatura de Control Escolar</Text>
        </View>

        <Text style={styles.direccionTexto}>{direccion}</Text>
        <Text style={styles.vigenciaTexto}>
          <Text style={styles.reversoLabel}>Vigencia:</Text> {vigencia}
        </Text>
      </View>
    </View>
  );
}

function UsuarioProvider({ children }) {
  const [estudiante, setEstudiante] = useState(estudiantePrincipal);
  const [mostrarReverso, setMostrarReverso] = useState(false);

  return (
    <UsuarioContext.Provider
      value={{ estudiante, setEstudiante, mostrarReverso, setMostrarReverso }}
    >
      {children}
    </UsuarioContext.Provider>
  );
}

function Reloj() {
  const [hora, setHora] = useState('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      now.setHours(now.getUTCHours() - 6);
      setHora(
        now.toLocaleTimeString('es-MX', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        }),
      );
    };

    updateClock();
    const timer = setInterval(updateClock, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <View style={styles.relojContainer}>
      <Text style={styles.relojTexto}>Hora actual (Ixtapaluca):</Text>
      <Text style={styles.relojHora}>{hora}</Text>
    </View>
  );
}

function Acciones() {
  const { mostrarReverso, setMostrarReverso } = useContext(UsuarioContext);

  return (
    <View style={styles.seccionAcciones}>
      <Button
        title={mostrarReverso ? 'Ver Frente' : 'Ver RFC/CURP'}
        onPress={() => setMostrarReverso(!mostrarReverso)}
        color="#800020"
      />
    </View>
  );
}

function AppWrapper() {
  return (
    <UsuarioProvider>
      <App />
    </UsuarioProvider>
  );
}

function App() {
  const { mostrarReverso } = useContext(UsuarioContext);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.credencialWrapper}>
        {mostrarReverso ? <CredencialReverso /> : <CredencialFrente />}
      </View>

      <View style={styles.separador} />

      <View style={styles.infoContainer}>
        <Reloj />
        <Acciones />
      </View>
    </SafeAreaView>
  );
}

export default AppWrapper;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F2F4F8',
    paddingHorizontal: 20,
  },
  credencialWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  infoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  credencialContainer: {
    width: 340,
    height: 540,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 15,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    overflow: 'hidden',
  },
  credencialContainerReverso: {
    width: 340,
    height: 540,
    backgroundColor: '#800020',
    borderRadius: 16,
    padding: 15,
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    overflow: 'hidden',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFD700',
  },
  colibriFondo: {
    position: 'absolute',
    width: '150%',
    height: '150%',
    opacity: 0.1,
    resizeMode: 'contain',
    top: '55%',
    left: '25%',
  },
  colibriFondoReverso: {
    position: 'absolute',
    width: '150%',
    height: '150%',
    opacity: 0.15,
    resizeMode: 'contain',
    top: '55%',
    left: '25%',
    tintColor: '#FFD700',
  },
  florCentral: {
    width: 35,
    height: 35,
    opacity: 0.7,
    resizeMode: 'contain',
    alignSelf: 'center',
    marginVertical: 10,
  },
  florCentralReverso: {
    position: 'absolute',
    width: 60,
    height: 60,
    opacity: 0.2,
    resizeMode: 'contain',
    alignSelf: 'center',
    top: '45%',
    tintColor: '#FFD700',
  },
  header: {
    alignItems: 'center',
    marginBottom: 5,
  },
  logo: {
    width: 280,
    height: 60,
    resizeMode: 'contain',
  },
  body: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingTop: 15,
  },
  fotoPerfil: {
    width: 140,
    height: 140,
    borderRadius: 70,
    borderWidth: 5,
    borderColor: '#FFD700',
    marginBottom: 10,
  },
  nombre: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#002147',
    lineHeight: 22,
  },
  rol: {
    fontSize: 16,
    color: '#666',
    marginTop: 5,
  },
  matricula: {
    fontSize: 20,
    fontWeight: 'bold',
    letterSpacing: 2,
    marginTop: 5,
    color: '#003366',
  },
  footer: {
    alignItems: 'center',
    paddingBottom: 10,
  },
  educacionTexto: {
    fontSize: 24,
    fontWeight: '900',
    color: '#002147',
    textAlign: 'center',
  },
  subtextoEducacion: {
    fontSize: 8,
    color: 'gray',
    textAlign: 'center',
    lineHeight: 10,
  },
  tesoemTexto: {
    fontSize: 10,
    fontWeight: 'bold',
    color: 'gray',
    textAlign: 'center',
    marginTop: 4,
    lineHeight: 12,
  },
  reversoContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    zIndex: 1,
  },
  reversoTexto: {
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 8,
    width: '100%',
  },
  reversoLabel: {
    fontWeight: 'bold',
    color: '#FFD700',
  },
  firmaContainer: {
    width: '100%',
    alignItems: 'center',
    marginVertical: 15,
  },
  firmaLabel: {
    color: '#FFFFFF',
    fontSize: 12,
  },
  firmaSubLabel: {
    color: '#FFD700',
    fontSize: 10,
    marginTop: 2,
  },
  direccionTexto: {
    color: '#E0E0E0',
    fontSize: 10,
    textAlign: 'center',
    width: '100%',
    marginTop: 20,
    lineHeight: 12,
  },
  vigenciaTexto: {
    color: '#FFD700',
    fontSize: 12,
    marginTop: 10,
    alignSelf: 'flex-end',
  },
  separador: {
    marginVertical: 20,
    height: 1,
    width: '80%',
    backgroundColor: '#CCCCCC',
  },
  relojContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  relojTexto: {
    fontSize: 16,
    color: '#002147',
    marginBottom: 5,
  },
  relojHora: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#800020',
  },
  seccionAcciones: {
    alignItems: 'center',
    width: '100%',
  },
});
