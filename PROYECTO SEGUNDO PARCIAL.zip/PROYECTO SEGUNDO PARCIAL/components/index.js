import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  ImageBackground,
  TouchableOpacity,
  Animated,
} from 'react-native';

const IndexScreen = ({ onEnter }) => {
  const fadeAnim = React.useRef(new Animated.Value(1)).current;
  const scaleAnim = React.useRef(new Animated.Value(1)).current;

  const handleEnter = () => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1.2,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onEnter();
    });
  };

  return (
    <ImageBackground
      source={require('../assets/welcome.jpg')}
      style={styles.background}
      resizeMode="cover"
    >
      <Animated.View
        style={[
          styles.welcomeContainer,
          {
            opacity: fadeAnim,
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <Text style={styles.welcomeTitle}>BIENVENIDO</Text>
        <Text style={styles.welcomeSubtitle}>A TU PROYECTO PARCIAL</Text>

        <View style={styles.featuresContainer}>
          <Text style={styles.featureText}>✨ Botones</Text>
          <Text style={styles.featureText}>🛍️ Catálogo</Text>
          <Text style={styles.featureText}>🎓 Credencial Digital</Text>
        </View>

        <TouchableOpacity style={styles.enterButton} onPress={handleEnter}>
          <Text style={styles.enterButtonText}>COMENZAR</Text>
        </TouchableOpacity>

        <Text style={styles.footerText}>SrCalvo Jazael Ontañon</Text>
      </Animated.View>
    </ImageBackground>
  );
};

export default IndexScreen;

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 10, 10, 0.85)',
    width: '100%',
    padding: 20,
  },
  welcomeTitle: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#ff6b6b',
    textAlign: 'center',
    marginBottom: 10,
    textShadowColor: '#ffd700',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
    letterSpacing: 2,
  },
  welcomeSubtitle: {
    fontSize: 24,
    color: '#4ecdc4',
    textAlign: 'center',
    marginBottom: 50,
    fontWeight: '600',
    textShadowColor: '#4ecdc4',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  featuresContainer: {
    marginBottom: 50,
    alignItems: 'center',
  },
  featureText: {
    fontSize: 18,
    color: '#ffe66d',
    marginVertical: 8,
    fontWeight: '500',
    textShadowColor: '#000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  enterButton: {
    backgroundColor: '#667eea',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 30,
    marginBottom: 30,
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.6,
    shadowRadius: 15,
    elevation: 8,
    borderWidth: 2,
    borderColor: '#ffe66d',
  },
  enterButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    textShadowColor: '#000',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  footerText: {
    color: '#95e1d3',
    fontSize: 14,
    marginTop: 20,
    fontStyle: 'italic',
  },
});
