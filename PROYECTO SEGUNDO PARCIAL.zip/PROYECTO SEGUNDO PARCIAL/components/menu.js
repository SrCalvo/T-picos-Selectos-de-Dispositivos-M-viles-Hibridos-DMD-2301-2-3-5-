import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Animated,
  StyleSheet,
  Easing,
  TouchableWithoutFeedback,
  ImageBackground,
} from 'react-native';

// Importar los componentes
import Botones from './botones';
import Catalogo from './catalogo';
import CredencialWrapper from './credencial';

const HamburgerMenu = ({ onGoToWelcome }) => {
  const [open, setOpen] = useState(false);
  const [currentScreen, setCurrentScreen] = useState('botones');
  const slideAnim = useRef(new Animated.Value(-280)).current;
  const overlayAnim = useRef(new Animated.Value(0)).current;

  const toggleMenu = () => {
    const toValue = open ? -280 : 0;
    const overlayTo = open ? 0 : 1;

    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue,
        duration: 300,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: false,
      }),
      Animated.timing(overlayAnim, {
        toValue: overlayTo,
        duration: 300,
        useNativeDriver: false,
      }),
    ]).start();

    setOpen(!open);
  };

  const handleNavigation = screen => {
    if (screen === 'index') {
      onGoToWelcome();
    } else {
      setCurrentScreen(screen);
      toggleMenu();
    }
  };

  const handleGoHome = () => {
    onGoToWelcome();
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'botones':
        return <Botones />;
      case 'catalogo':
        return <Catalogo />;
      case 'credencial':
        return <CredencialWrapper />;
      default:
        return <Botones />;
    }
  };

  return (
    <View style={styles.container}>
      {/* Overlay */}
      <Animated.View
        pointerEvents={open ? 'auto' : 'none'}
        style={[
          styles.overlay,
          {
            opacity: overlayAnim,
          },
        ]}
      >
        <TouchableWithoutFeedback onPress={toggleMenu}>
          <View style={styles.overlayTouchable} />
        </TouchableWithoutFeedback>
      </Animated.View>

      {/* Menú lateral */}
      <Animated.View
        style={[
          styles.menu,
          {
            left: slideAnim,
          },
        ]}
      >
        <ImageBackground
          source={require('../assets/menu-bg.jpg')}
          style={styles.menuBackground}
          resizeMode="cover"
        >
          <View style={styles.menuContent}>
            <Text style={styles.menuTitle}>🚀 Menú Principal</Text>

            <TouchableOpacity onPress={() => handleNavigation('index')}>
              <Text style={styles.menuItem}>🏠 Pantalla de Inicio</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => handleNavigation('botones')}>
              <Text
                style={[
                  styles.menuItem,
                  currentScreen === 'botones' && styles.activeMenuItem,
                ]}
              >
                🎮 Botones Interactivos
              </Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => handleNavigation('catalogo')}>
              <Text
                style={[
                  styles.menuItem,
                  currentScreen === 'catalogo' && styles.activeMenuItem,
                ]}
              >
                🛍️ Catálogo Productos
              </Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={() => handleNavigation('credencial')}>
              <Text
                style={[
                  styles.menuItem,
                  currentScreen === 'credencial' && styles.activeMenuItem,
                ]}
              >
                🎓 Credencial TESOEM
              </Text>
            </TouchableOpacity>
          </View>
        </ImageBackground>
      </Animated.View>

      {/* Botón de hamburguesa */}
      <TouchableOpacity onPress={toggleMenu} style={styles.hamburgerButton}>
        <View
          style={[styles.bar, { backgroundColor: open ? '#fff' : '#333' }]}
        />
        <View
          style={[styles.bar, { backgroundColor: open ? '#fff' : '#333' }]}
        />
        <View
          style={[styles.bar, { backgroundColor: open ? '#fff' : '#333' }]}
        />
      </TouchableOpacity>

      {/* Botón de regreso al inicio */}
      <TouchableOpacity onPress={handleGoHome} style={styles.homeButton}>
        <Text style={styles.homeButtonText}>🏠</Text>
      </TouchableOpacity>

      {/* Contenido principal */}
      <View style={styles.content}>{renderScreen()}</View>
    </View>
  );
};

export default HamburgerMenu;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0a0a',
  },
  hamburgerButton: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 10,
    borderRadius: 10,
    elevation: 10,
  },
  homeButton: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 100,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    padding: 10,
    borderRadius: 10,
    elevation: 10,
  },
  homeButtonText: {
    fontSize: 20,
  },
  bar: {
    width: 25,
    height: 3,
    marginVertical: 3,
    borderRadius: 2,
  },
  menu: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    width: 280,
    backgroundColor: '#000',
    elevation: 20,
    zIndex: 90,
  },
  menuBackground: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  menuContent: {
    flex: 1,
    paddingTop: 100,
    paddingHorizontal: 25,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.7)',
    zIndex: 80,
  },
  overlayTouchable: {
    flex: 1,
  },
  menuTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#ff6b6b',
    textAlign: 'center',
    textShadowColor: 'rgba(255, 255, 255, 0.3)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  menuItem: {
    fontSize: 18,
    paddingVertical: 15,
    color: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
    fontWeight: '500',
  },
  activeMenuItem: {
    color: '#4ecdc4',
    fontWeight: 'bold',
    backgroundColor: 'rgba(78, 205, 196, 0.1)',
    paddingLeft: 10,
    borderRadius: 8,
  },
  content: {
    flex: 1,
    zIndex: 1,
  },
});
